# 🚀 Guia de Instalação - Email Templates v2.0

**Data:** 01 de Dezembro de 2025

---

## 📋 Pré-requisitos

- Laravel 8+
- Mailer configurado (SMTP, SendGrid, etc)
- Acesso ao servidor/desenvolvimento
- Backup do projeto (recomendado)

---

## ⚡ Instalação Rápida (3 passos)

### Passo 1: Copiar Arquivos de Email

```bash
# Copiar templates de email
cp resources/views/emails/ordem-servico.blade.php seu-projeto/resources/views/emails/
cp resources/views/emails/ordem-servico-consultor.blade.php seu-projeto/resources/views/emails/
cp resources/views/emails/ordem-servico-cliente.blade.php seu-projeto/resources/views/emails/
```

### Passo 2: Copiar Mailable Atualizada

```bash
# Copiar classe de email
cp app/Mail/OrdemServicoMail.php seu-projeto/app/Mail/
```

### Passo 3: Testar

```bash
# Iniciar tinker
php artisan tinker

# Testar envio para consultor
$os = App\Models\OrdemServico::first();
Mail::to($os->consultor->email)->send(new App\Mail\OrdemServicoMail($os, 'consultor'));

# Testar envio para cliente
Mail::to($os->cliente->email)->send(new App\Mail\OrdemServicoMail($os, 'cliente'));
```

---

## 📁 Estrutura de Diretórios

Seus arquivos devem ficar assim:

```
seu-projeto/
├─ resources/
│  └─ views/
│     └─ emails/
│        ├─ ordem-servico.blade.php              (legacy)
│        ├─ ordem-servico-consultor.blade.php    ⭐ NOVO
│        ├─ ordem-servico-cliente.blade.php      ⭐ NOVO
│        └─ ... (outros templates)
│
└─ app/
   └─ Mail/
      ├─ OrdemServicoMail.php                    (atualizado)
      └─ ... (outras mailable)
```

---

## 🔄 Fluxo de Uso

### 1. Enviar para Consultor

```php
// Em seu controller ou service
$ordemServico = OrdemServico::find($id);

// Carregar relacionamentos
$ordemServico->load('consultor', 'cliente');

// Enviar email
Mail::to($ordemServico->consultor->email)
    ->send(new OrdemServicoMail($ordemServico, 'consultor'));
```

**Resultado:** Email do CONSULTOR com "RESUMO - SEU GANHO"

---

### 2. Enviar para Cliente

```php
// Em seu controller ou service
$ordemServico = OrdemServico::find($id);

// Carregar relacionamentos
$ordemServico->load('consultor', 'cliente');

// Enviar email
Mail::to($ordemServico->cliente->email)
    ->send(new OrdemServicoMail($ordemServico, 'cliente'));
```

**Resultado:** Email do CLIENTE com "RESUMO FINANCEIRO"

---

### 3. Enviar para Ambos

```php
// Em seu controller ou service
$ordemServico = OrdemServico::find($id);

// Carregar relacionamentos
$ordemServico->load('consultor', 'cliente');

// Enviar para ambos
Mail::to($ordemServico->consultor->email)
    ->send(new OrdemServicoMail($ordemServico, 'consultor'));

Mail::to($ordemServico->cliente->email)
    ->send(new OrdemServicoMail($ordemServico, 'cliente'));
```

---

## 🧪 Teste de Integração

### 1. Teste Local (Mail Fake)

```php
// Em seu teste automatizado
public function test_ordem_servico_email_consultant()
{
    Mail::fake();

    $os = OrdemServico::factory()->create();
    $os->load('consultor', 'cliente');

    Mail::to($os->consultor->email)->send(new OrdemServicoMail($os, 'consultor'));

    Mail::assertSent(OrdemServicoMail::class, function ($mail) {
        return $mail->hasTo($os->consultor->email);
    });
}

public function test_ordem_servico_email_client()
{
    Mail::fake();

    $os = OrdemServico::factory()->create();
    $os->load('consultor', 'cliente');

    Mail::to($os->cliente->email)->send(new OrdemServicoMail($os, 'cliente'));

    Mail::assertSent(OrdemServicoMail::class, function ($mail) {
        return $mail->hasTo($os->cliente->email);
    });
}
```

### 2. Teste Real (Preview)

```bash
# Usar Laravel Mailbox para preview
php artisan tinker

$os = OrdemServico::with('consultor', 'cliente')->first();
(new OrdemServicoMail($os, 'consultor'))->render();  // Visualizar HTML
```

---

## 🔧 Verificações

### Verificar Relacionamentos

```php
// Garantir que os relacionamentos estão definidos no Model
// Em app/Models/OrdemServico.php

public function consultor()
{
    return $this->belongsTo(User::class, 'consultor_id');
}

public function cliente()
{
    return $this->belongsTo(Cliente::class, 'cliente_id');
}
```

### Verificar Campos

```php
// Garantir que todos os campos existem na BD
Schema::table('ordem_servico', function (Blueprint $table) {
    $table->string('data_emissao')->nullable();
    $table->string('hora_inicio')->nullable();
    $table->string('hora_final')->nullable();
    $table->string('hora_desconto')->nullable();
    $table->string('qtde_total')->nullable();
    $table->string('valor_despesa')->nullable();
    $table->decimal('deslocamento', 10, 2)->nullable();
    $table->string('km')->nullable();
    $table->string('valor_total')->nullable();
    $table->text('detalhamento')->nullable();
});
```

---

## 📊 Validação Pós-Instalação

- [ ] Email do Consultor recebido com layout correto
- [ ] Email do Cliente recebido com layout correto
- [ ] TRANSLADO aparece em ambos (calculado com valor_hora)
- [ ] VALOR TOTAL correto em ambos
- [ ] Logo Personalitec visível no rodapé
- [ ] Cores azul vibrante em ambos
- [ ] Layout responsivo no mobile
- [ ] Links não quebrados
- [ ] Imagens carregando corretamente

---

## ⚠️ Troubleshooting

### Problema: Email não é enviado

```php
// Verificar se o mailer está configurado
php artisan config:show mail

// Testar conexão SMTP
php artisan mail:send
```

### Problema: Template não encontrado

```
Erro: View [emails.ordem-servico-consultor] not found.
```

**Solução:** Garantir que os arquivos `.blade.php` estão em:
```
resources/views/emails/ordem-servico-consultor.blade.php
resources/views/emails/ordem-servico-cliente.blade.php
```

### Problema: Campos vazios no email

```php
// Garantir que os relacionamentos estão carregados
$os->load('consultor', 'cliente');

// Ou ao buscar
$os = OrdemServico::with('consultor', 'cliente')->find($id);
```

### Problema: TRANSLADO mostra "--"

**Causa:** Campo `deslocamento` vazio ou `consultor.valor_hora` não configurado

**Solução:**
```php
// Verificar se o campo existe
$os->deslocamento; // deve ter um valor decimal

// Verificar se valor_hora está definido
$os->consultor->valor_hora; // deve ter um valor decimal
```

---

## 🔄 Rollback (se necessário)

Se precisar reverter para o template único:

```php
// Em app/Mail/OrdemServicoMail.php
public function content(): Content
{
    return new Content(
        view: 'emails.ordem-servico',  // Template antigo
        with: [
            'ordemServico' => $this->ordemServico,
            'tipoDestinatario' => $this->tipoDestinatario,
        ],
    );
}
```

---

## 📞 Suporte

Para dúvidas ou problemas:

1. Verifique o [README.md](README.md)
2. Consulte a documentação dos templates
3. Verifique os logs em `storage/logs/`

---

## ✅ Checklist Final

- [ ] Arquivos copiados para os diretórios corretos
- [ ] Mailable atualizada
- [ ] Relacionamentos carregados no serviço de email
- [ ] Teste local realizado
- [ ] Email de consultor recebido e validado
- [ ] Email de cliente recebido e validado
- [ ] Layout testado em diferentes clientes de email
- [ ] Documentação revisada
- [ ] Backup realizado

---

**Versão:** 2.0
**Data:** 01 de Dezembro de 2025
**Status:** ✅ PRONTO PARA PRODUÇÃO

Siga os passos acima e a implementação será bem-sucedida!
