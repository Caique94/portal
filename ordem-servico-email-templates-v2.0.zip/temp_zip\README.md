# 📧 Email Templates - Ordem de Serviço v2.0

**Data:** 01 de Dezembro de 2025
**Status:** ✅ PRONTO PARA PRODUÇÃO

---

## 📋 Conteúdo do Pacote

Este ZIP contém os arquivos de email para Ordem de Serviço com suporte a **dois templates separados** - um para consultor e outro para cliente.

### Arquivos Inclusos

```
📁 resources/views/emails/
  ├─ ordem-servico.blade.php              (Template legado - pode ser deprecado)
  ├─ ordem-servico-consultor.blade.php    ⭐ NOVO - Email para Consultor
  └─ ordem-servico-cliente.blade.php      ⭐ NOVO - Email para Cliente

📁 app/Mail/
  └─ OrdemServicoMail.php                 (Atualizada - roteia para template correto)
```

---

## 🎯 Visão Geral

### Email do CONSULTOR 👷

**Arquivo:** `recursos/views/emails/ordem-servico-consultor.blade.php`

**Características:**
- ✅ Mostra valor/hora do consultor
- ✅ Tabela completa de horas com TRANSLADO
- ✅ Cálculo de "VALOR TOTAL" (ganhos):
  - (Total Horas × Valor/Hora) + (KM × Valor/KM) + (Deslocamento × Valor/Hora) + Despesas

**Seções:**
1. Informações do Cliente e Horas
2. Detalhamento do Atendimento
3. **RESUMO - SEU GANHO** com VALOR TOTAL

---

### Email do CLIENTE 💼

**Arquivo:** `recursos/views/emails/ordem-servico-cliente.blade.php`

**Características:**
- ✅ Informações focadas no cliente
- ✅ Tabela completa de horas com TRANSLADO (para transparência)
- ✅ Mostra "VALOR TOTAL" a pagar:
  - Usa campo `valor_total` do banco de dados

**Seções:**
1. Informações do Consultor e Horas
2. Detalhes do Atendimento
3. **RESUMO FINANCEIRO** com VALOR TOTAL

---

## 🔧 Implementação

### 1. Copiar Arquivos

```bash
# Copie os arquivos para seus respectivos diretórios
cp -r resources/views/emails/*.blade.php seu-projeto/resources/views/emails/
cp app/Mail/OrdemServicoMail.php seu-projeto/app/Mail/
```

### 2. Verificar a Mailable

O arquivo `OrdemServicoMail.php` já contém a lógica de roteamento:

```php
public function content(): Content
{
    // Seleciona o template baseado no tipo de destinatário
    $view = $this->tipoDestinatario === 'consultor'
        ? 'emails.ordem-servico-consultor'
        : 'emails.ordem-servico-cliente';

    return new Content(
        view: $view,
        with: [
            'ordemServico' => $this->ordemServico,
            'tipoDestinatario' => $this->tipoDestinatario,
        ],
    );
}
```

### 3. Usar no Seu Código

```php
// Enviar para Consultor
Mail::to($consultor->email)->send(new OrdemServicoMail($os, 'consultor'));

// Enviar para Cliente
Mail::to($cliente->email)->send(new OrdemServicoMail($os, 'cliente'));
```

---

## 📊 Comparação

| Aspecto | Consultor | Cliente |
|--------|-----------|---------|
| **Template** | ordem-servico-consultor | ordem-servico-cliente |
| **Tabela Horas** | ✅ Completa | ✅ Completa |
| **TRANSLADO** | ✅ Sim | ✅ Sim |
| **Valor/Hora** | Seu valor | Valor do cliente |
| **Seção Total** | RESUMO - SEU GANHO | RESUMO FINANCEIRO |
| **Cálculo Total** | (horas×rate) + km + deslocamento + despesas | valor_total (BD) |

---

## 🎨 Design

Ambos os templates utilizam:
- ✅ Gradiente azul vibrante (#1E88E5-#42A5F5)
- ✅ Layout responsivo (mobile-friendly)
- ✅ Tabelas com bordas e espaçamento profissional
- ✅ Logo Personalitec no rodapé
- ✅ Cores consistentes com brand

---

## 📝 Campos Utilizados

### Do Objeto `$ordemServico`

```
- id                    (ID da OS)
- nr_atendimento        (Número do chamado)
- data_emissao          (Data de emissão)
- hora_inicio           (Horário de início)
- hora_final            (Horário de término)
- hora_desconto         (Horas descontadas)
- qtde_total            (Total de horas)
- valor_despesa         (Valor de despesa)
- deslocamento          (Horas de deslocamento)
- km                    (Quilômetros)
- valor_total           (Total final)
- detalhamento          (Descrição do trabalho)
```

### Do Objeto `$ordemServico->consultor` (User)

```
- name                  (Nome do consultor)
- valor_hora            (Valor/hora do consultor)
- valor_km              (Valor/KM do consultor)
```

### Do Objeto `$ordemServico->cliente` (Cliente)

```
- nome                  (Nome do cliente)
- nome_fantasia         (Razão social)
- email                 (Email do cliente)
- contato               (Contato alternativo)
```

---

## ✅ Checklist de Instalação

- [ ] Copiar arquivos `.blade.php` para `resources/views/emails/`
- [ ] Copiar `OrdemServicoMail.php` para `app/Mail/`
- [ ] Verificar que `OrdemServicoEmailService.php` está passando o parâmetro `'consultor'` ou `'cliente'`
- [ ] Testar envio para consultor
- [ ] Testar envio para cliente
- [ ] Validar layout em diferentes clientes de email (Gmail, Outlook, etc)

---

## 🔄 Histórico de Versões

### v2.0 - 01 de Dezembro de 2025
- ✅ Criar templates separados para consultor e cliente
- ✅ Adicionar tabela de horas no email do cliente
- ✅ Padronizar label "VALOR TOTAL" em ambos os templates
- ✅ Melhorar roteamento automático na Mailable

### v1.0 - 02 de Dezembro de 2024
- Template único para ambos os destinatários

---

## 📞 Suporte

Se encontrar problemas:

1. **Verifique se os relacionamentos estão carregados:**
   ```php
   $ordemServico->load('consultor', 'cliente');
   ```

2. **Verifique se os campos existem na BD:**
   ```php
   DB::table('ordem_servico')->first();
   ```

3. **Teste localmente antes de produção:**
   ```php
   Mail::fake();
   // ... seu código de teste
   Mail::assertSent(OrdemServicoMail::class);
   ```

---

## 📦 Dependências

- Laravel 8+ (compatível com 9, 10, 11)
- Mailer configurado (SMTP, SendGrid, etc)
- Carbon para manipulação de datas

---

## 🎓 Referências

- [Laravel Mail Documentation](https://laravel.com/docs/mail)
- [Blade Email Documentation](https://laravel.com/docs/mail#markdown-mailables)
- [HTML Email Best Practices](https://www.campaignmonitor.com/css/)

---

**Versão:** 2.0
**Data:** 01 de Dezembro de 2025
**Status:** ✅ PRONTO PARA USAR

Todos os arquivos foram testados e validados. O pacote está pronto para implementação em produção.
