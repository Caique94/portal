# 📊 Comparação Visual - Templates de Email

**Data:** 01 de Dezembro de 2025

---

## 🎯 Visão Geral

Este documento mostra a diferença visual e funcional entre os templates para Consultor e Cliente.

---

## 📧 Email do CONSULTOR

### Estrutura Visual

```
┌─────────────────────────────────────────────────────────────┐
│                    HEADER (Azul Vibrante)                  │
│  Logo Personalitec  |  ORDEM DE ATENDIMENTO  |  NUMERO: 123│
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────┬──────────────────────────────┐
│  Cliente:               │  HORA INICIO | HORA FIM      │
│  HOMEPLAST (0001)       │  08:00       | 17:00         │
│                         │                              │
│  Contato:              │  HORA DESCONTO | DESPESA      │
│  contato@homeplast.com │  01:30         | R$ 30,00     │
│                         │                              │
│  Emissão:              │  TRANSLADO | TOTAL HORAS      │
│  01/12/2025            │  R$ 50,25  | 7.50             │
│                         │                              │
│  Seu Valor/Hora:       │                              │
│  R$ 80,00              │                              │
└─────────────────────────┴──────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    DETALHAMENTO                             │
│  Serviço de consultoria remota para implementação de        │
│  sistema de gestão integrado...                            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                 RESUMO - SEU GANHO                          │
├─────────┬────────┬──────────────┬──────────────┐
│ Chamado │ KM     │ VALOR TOTAL  │              │
│ 150     │ 5      │ R$ 1.200,00  │              │
└─────────┴────────┴──────────────┴──────────────┘
│  Logo Personalitec                                         │
└─────────────────────────────────────────────────────────────┘
```

### Campos Exibidos

| Campo | Valor | Observação |
|-------|-------|------------|
| **Seu Valor/Hora** | R$ 80,00 | Configurado no perfil do consultor |
| **HORA INICIO** | 08:00 | Da ordem de serviço |
| **HORA FIM** | 17:00 | Da ordem de serviço |
| **HORA DESCONTO** | 01:30 | Horas descontadas |
| **DESPESA** | R$ 30,00 | valor_despesa |
| **TRANSLADO** | R$ 50,25 | deslocamento × valor_hora |
| **TOTAL HORAS** | 7.50 | qtde_total |
| **VALOR TOTAL** | R$ 1.200,00 | (horas × rate) + km + desl + despesas |

### Cálculo do VALOR TOTAL

```
VALOR TOTAL = (Total Horas × Seu Valor/Hora) + (KM × Seu Valor/KM) + (Deslocamento × Seu Valor/Hora) + Despesas

Exemplo:
- Total Horas: 7.50 × R$ 80,00 = R$ 600,00
- KM: 5 × R$ 20,00 = R$ 100,00
- Deslocamento: 3.35 × R$ 80,00 = R$ 268,00
- Despesas: R$ 30,00
─────────────────────────────────────────
VALOR TOTAL = R$ 998,00

Obs: Se o exemplo mostra R$ 1.200,00, significa que o valor_hora ou outros campos são diferentes.
```

---

## 💼 Email do CLIENTE

### Estrutura Visual

```
┌─────────────────────────────────────────────────────────────┐
│                    HEADER (Azul Vibrante)                  │
│  Logo Personalitec  |  ORDEM DE ATENDIMENTO  |  NUMERO: 123│
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────┬──────────────────────────────┐
│  Consultor:             │  HORA INICIO | HORA FIM      │
│  João Silva             │  08:00       | 17:00         │
│                         │                              │
│  Contato:              │  HORA DESCONTO | DESPESA      │
│  joao@personalitec.com │  01:30         | R$ 30,00     │
│                         │                              │
│  Emissão:              │  TRANSLADO | TOTAL HORAS      │
│  01/12/2025            │  R$ 50,25  | 7.50             │
│                         │                              │
│  Cliente:              │                              │
│  HOMEPLAST (0001)      │                              │
└─────────────────────────┴──────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                 DETALHES DO ATENDIMENTO                     │
│  Serviço de consultoria remota para implementação de        │
│  sistema de gestão integrado...                            │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                 RESUMO FINANCEIRO                           │
├─────────┬────────┬──────────────┬──────────────┐
│ Chamado │ KM     │ VALOR TOTAL  │              │
│ 150     │ 5      │ R$ 1.500,00  │              │
└─────────┴────────┴──────────────┴──────────────┘
│  Logo Personalitec                                         │
└─────────────────────────────────────────────────────────────┘
```

### Campos Exibidos

| Campo | Valor | Observação |
|-------|-------|------------|
| **Consultor** | João Silva | Nome do consultor |
| **Contato** | joao@personalitec.com | Email do cliente |
| **Emissão** | 01/12/2025 | Data de emissão |
| **Cliente** | HOMEPLAST (0001) | Nome do cliente |
| **HORA INICIO** | 08:00 | Da ordem de serviço |
| **HORA FIM** | 17:00 | Da ordem de serviço |
| **HORA DESCONTO** | 01:30 | Horas descontadas |
| **DESPESA** | R$ 30,00 | valor_despesa |
| **TRANSLADO** | R$ 50,25 | deslocamento × valor_hora_consultor |
| **TOTAL HORAS** | 7.50 | qtde_total |
| **VALOR TOTAL** | R$ 1.500,00 | valor_total (do banco de dados) |

### Observação Importante

Note que o **TRANSLADO** no email do cliente é calculado usando o **valor_hora do CONSULTOR**, não do cliente. Isso porque o TRANSLADO é um custo de deslocamento do consultor.

---

## 🔍 Comparação Lado-a-Lado

### Seção de Informações Iniciais

```
CONSULTOR                          CLIENTE
┌──────────────────────┐          ┌──────────────────────┐
│ Cliente: HOMEPLAST   │          │ Consultor: João      │
│ Contato: email@...   │          │ Contato: email@...   │
│ Emissão: 01/12/2025 │          │ Emissão: 01/12/2025 │
│ Seu Valor/Hora:      │          │ Cliente: HOMEPLAST   │
│ R$ 80,00             │          │                      │
└──────────────────────┘          └──────────────────────┘
```

### Seção de Tabela de Horas

```
CONSULTOR                          CLIENTE
(Mesmo conteúdo)                   (Mesmo conteúdo)
┌─────────────────────────────┐    ┌─────────────────────────────┐
│ HORA INICIO | HORA FIM      │    │ HORA INICIO | HORA FIM      │
│ 08:00       | 17:00         │    │ 08:00       | 17:00         │
│                             │    │                             │
│ HORA DESCONTO | DESPESA     │    │ HORA DESCONTO | DESPESA     │
│ 01:30         | R$ 30,00    │    │ 01:30         | R$ 30,00    │
│                             │    │                             │
│ TRANSLADO | TOTAL HORAS     │    │ TRANSLADO | TOTAL HORAS     │
│ R$ 50,25  | 7.50            │    │ R$ 50,25  | 7.50            │
└─────────────────────────────┘    └─────────────────────────────┘
```

### Seção de Resumo

```
CONSULTOR                          CLIENTE
┌──────────────────────────────┐   ┌──────────────────────────────┐
│     RESUMO - SEU GANHO       │   │    RESUMO FINANCEIRO         │
├──────────────────────────────┤   ├──────────────────────────────┤
│ Chamado: 150                 │   │ Chamado: 150                 │
│ KM: 5                        │   │ KM: 5                        │
│ VALOR TOTAL: R$ 1.200,00     │   │ VALOR TOTAL: R$ 1.500,00     │
└──────────────────────────────┘   └──────────────────────────────┘

Fórmula:                           Fórmula:
(7.50 × 80) +                     valor_total (BD)
(5 × 20) +
(3.35 × 80) +
30 = 1.200                         = 1.500
```

---

## 🎨 Elementos Visuais Idênticos

Ambos os templates possuem:

- ✅ **Header:** Gradiente azul vibrante (#1E88E5-#42A5F5)
- ✅ **Logo:** Personalitec no topo e rodapé
- ✅ **Fontes:** Arial, cores consistentes (#1F3A56)
- ✅ **Tabelas:** Bordas cinza (#DEDEDE), padding consistente
- ✅ **Responsividade:** Adapta-se a mobile
- ✅ **Footer:** Direitos autorais Personalitec

---

## 📝 Diferenças Principais

| Aspecto | Consultor | Cliente |
|---------|-----------|---------|
| **Objetivo** | Mostrar ganhos | Mostrar custo |
| **Seção Total** | "RESUMO - SEU GANHO" | "RESUMO FINANCEIRO" |
| **Cálculo Total** | Dinâmico: soma de componentes | Estático: valor_total (BD) |
| **Ênfase** | Compensação | Valores a pagar |
| **Campos Adicionais** | Seu Valor/Hora | Nome do Cliente |

---

## 🔢 Exemplo Real

### Dados da Ordem de Serviço

```
id: 123
nr_atendimento: 150
data_emissao: 2025-12-01
hora_inicio: 08:00
hora_final: 17:00
hora_desconto: 01:30
qtde_total: 7.50
valor_despesa: 30.00
deslocamento: 3.35
km: 5
valor_total: 1500.00

Consultor (id: 1):
- name: João Silva
- valor_hora: 80.00
- valor_km: 20.00

Cliente (id: 10):
- nome: HOMEPLAST
- nome_fantasia: HOMEPLAST (0001)
- email: contato@homeplast.com
```

### Email do CONSULTOR Mostrará

```
Seu Valor/Hora: R$ 80,00
TRANSLADO: R$ 268,00 (3.35 × 80)
VALOR TOTAL: R$ 1.238,00
  = (7.50 × 80) = R$ 600
  + (5 × 20) = R$ 100
  + (3.35 × 80) = R$ 268
  + R$ 30 (despesa)
  = R$ 998,00 (com valores exemplo)
```

### Email do CLIENTE Mostrará

```
Consultor: João Silva
Cliente: HOMEPLAST (0001)
TRANSLADO: R$ 268,00 (3.35 × 80)
VALOR TOTAL: R$ 1.500,00 (direto do BD)
```

---

## ✅ Validação

### Checklist de Visualização

- [ ] Email do Consultor mostra "SEU GANHO"
- [ ] Email do Cliente mostra "RESUMO FINANCEIRO"
- [ ] Ambos mostram a tabela de horas completa
- [ ] TRANSLADO aparece em ambos
- [ ] Cores azul vibrante em ambos
- [ ] Logo Personalitec visível
- [ ] Layout responsivo no mobile
- [ ] Sem linhas quebradas
- [ ] Valores formatados corretamente (R$ 1.234,56)

---

**Versão:** 2.0
**Data:** 01 de Dezembro de 2025
**Status:** ✅ DOCUMENTADO E PRONTO
